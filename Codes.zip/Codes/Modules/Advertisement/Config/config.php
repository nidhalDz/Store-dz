<?php

return [
    'name' => 'Advertisement'
];

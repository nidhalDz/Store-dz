<?php

namespace Modules\Advertisement\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface AdvertisementRepository.
 *
 * @package namespace Modules\Advertisement\Eloquent\Interfaces;
 */
interface AdvertisementRepository extends RepositoryInterface
{
    //
}

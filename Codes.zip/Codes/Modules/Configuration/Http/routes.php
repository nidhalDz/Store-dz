<?php

// Route::group(['middleware' => 'web', 'prefix' => 'configuration', 'namespace' => 'Modules\Configuration\Http\Controllers'], function()
// {
//     Route::get('/', 'ConfigurationController@index');
// });

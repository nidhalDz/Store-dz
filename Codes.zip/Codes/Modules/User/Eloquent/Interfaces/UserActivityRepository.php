<?php

namespace Modules\User\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface UserActivityRepository.
 *
 * @package namespace Modules\User\Eloquent\Interfaces;
 */
interface UserActivityRepository extends RepositoryInterface
{
    //
}

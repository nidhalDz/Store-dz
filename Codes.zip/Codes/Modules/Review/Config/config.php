<?php

return [
    'name' => 'Review',

    /*
    |--------------------------------------------------------------------------
    | Review Model
    | change based on your model that you want to add review features
    |--------------------------------------------------------------------------
    */
    'model' => \Modules\Review\Eloquent\Entities\Review::class,
];

<?php

return [

    'default_login_routes' => 'web.user.index'
 
];
<?php

return [

    'app' => [
        'limit_version_show_to' => 6
    ]

];
<?php

namespace App\App\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface HomePageFooterRepository.
 *
 * @package namespace App\App\Eloquent\Interfaces;
 */
interface HomePageFooterRepository extends RepositoryInterface
{
    //
}

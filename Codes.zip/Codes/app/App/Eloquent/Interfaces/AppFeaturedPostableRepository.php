<?php

namespace App\App\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface AppFeaturedPostableRepository.
 *
 * @package namespace App\App\Eloquent\Interfaces;
 */
interface AppFeaturedPostableRepository extends RepositoryInterface
{
    //
}

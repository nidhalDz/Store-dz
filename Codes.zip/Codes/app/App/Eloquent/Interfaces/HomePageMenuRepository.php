<?php

namespace App\App\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface HomePageMenuRepository.
 *
 * @package namespace App\App\Eloquent\Interfaces;
 */
interface HomePageMenuRepository extends RepositoryInterface
{
    //
}

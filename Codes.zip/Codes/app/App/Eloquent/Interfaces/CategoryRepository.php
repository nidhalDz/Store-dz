<?php

namespace App\App\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CategoryRepository.
 *
 * @package namespace App\App\Eloquent\Interfaces;
 */
interface CategoryRepository extends RepositoryInterface
{
    //
}

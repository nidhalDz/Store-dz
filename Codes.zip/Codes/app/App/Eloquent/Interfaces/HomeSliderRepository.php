<?php

namespace App\App\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface HomeSliderRepository.
 *
 * @package namespace App\App\Eloquent\Interfaces;
 */
interface HomeSliderRepository extends RepositoryInterface
{
    //
}

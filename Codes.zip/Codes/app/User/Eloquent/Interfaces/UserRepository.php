<?php

namespace App\User\Eloquent\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface UserRepository.
 *
 * @package namespace App\User\Eloquent\Interfaces;
 */
interface UserRepository extends RepositoryInterface
{
    //
}
